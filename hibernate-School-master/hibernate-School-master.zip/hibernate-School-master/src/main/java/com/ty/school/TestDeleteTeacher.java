package com.ty.school;

public class TestDeleteTeacher {
	public static void main(String[] args) {
		
	}
}
